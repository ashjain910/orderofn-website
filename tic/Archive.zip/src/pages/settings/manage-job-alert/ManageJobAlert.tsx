export default function ManageJobAlert() {
  return (
    <div>
      <h1>Manage Job Alert Page</h1>
    </div>
  );
}
